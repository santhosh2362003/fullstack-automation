const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());

// Intha URL thaan Database connection-ku mukkiyam
// "db" nu kudutha athu Docker-la irukka Database container-a auto-ah connect pannum
const mongoURI = process.env.DB_URL || 'mongodb://db:27017/jenkins_task';

mongoose.connect(mongoURI)
    .then(() => console.log('MongoDB Connected Successfully!'))
    .catch(err => console.log('DB Connection Error: ', err));

app.get('/api/status', (req, res) => {
    res.json({ message: "Fullstack Automation Success! Backend & DB Live." });
});

app.listen(5000, () => console.log('Backend server running on port 5000'));